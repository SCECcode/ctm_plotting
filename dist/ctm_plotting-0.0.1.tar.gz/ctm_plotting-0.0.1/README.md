
[![License](https://img.shields.io/badge/License-BSD_3--Clause-blue.svg)](https://opensource.org/licenses/BSD-3-Clause)
![GitHub repo size](https://img.shields.io/github/repo-size/sceccode/ctm_plotting)

# ctm_plotting

# Description: 
This ctm_plotting software 

# Table of Contents:
1. [Software Documentation](https://github.com/SCECcode/ctm_plotting/wiki)
2. [Installation](#installation)
3. [Usage](#usage)
4. [Support](#support)
5. [Contributing](#contributing)
6. [Credits](#credits)
7. [License](#license)

# Installation: 
Prerequisite :  anaconda with python3 virtual environment. The python3 environment should include the 
following libraries. It is highly recommended to create an environment with this command to bring in 
the required python XXX modules
 
* conda create -n python3 python>3.0 scipy pip numpy matplotlib

* git clone https://github.com/SCECcode/ctm_plotting.git
* cd into ctm_plotting
* ./unpack-dist
* This will build the ctm_plotting utilities, and add the ctm_plotting scripts to the users path.

* If needs to repackage the ctm_plotting (./make-dist), need addictional python pkg  
*    conda install setuptools wheel

# Usage:
Once ctm_plotting is installed, users can run ctm_plotting scripts like this:

### plot_depth_profile.py

The following command will produce a depth profile of CVM-H v15.1 for Vs, Vp and density at (34,-118) from depth of 0 to 50000m
<pre>
./plot_depth_profile.py -s 34,-118 -b 0 -e 50000 -d vs,vp,density -v 500 -c cvmh -o depth_profile.png
</pre>

[<img src="https://github.com/SCECcode/ctm_plotting/wiki/images/plots/depth_profile.png" width="300" height="300" />](https://github.com/SCECcode/ctm_plotting/wiki/images/plots/depth_profile.png)

### plot_horizontal.py
The following command will produce a horizontal map view plot plot of Vs values from CVM-H v15.1 at a depth of 500m for the Los Angeles region.
<pre>
./plot_horizontal_slice.py -b 33.5,-118.75 -u 34.5,-117.5 -s 0.01 -e 500 -d vs -a s -c cvmh
</pre>
[<img src="https://github.com/SCECcode/ctm_plotting/wiki/images/plots/horizontal_slice_1.png" width="300" height="300" />](http://github.com/SCECcode/ctm_plotting/wiki/images/plots/horizontal_slice_1.png)

Please see the [ctm_plotting documetation](https://github.com/sceccode/ctm_plotting/wiki) for more information and examples.

# Support:
Support for ctm_plotting is provided by that Statewide California Earthquake Center (SCEC) Research Computing Group. This group supports several research software distributions including CTM. Users can report issues and feature requests using CTM's github-based issue tracking link below. Developers will also respond to emails sent to the SCEC software contact listed below.
1. [CTM Github Issue Tracker:](https://github.com/SCECcode/ctm_plotting/issues)
2. Email Contact: software@scec.usc.edu

# Contributing:
We welcome contributions to the ctm_plotting software utilities. An overview of the process for contributing seismic models or 
software updates to the ctm_plotting Project is provided in the ctm_plotting [contribution guidelines](CONTRIBUTING.md). 
ctm_plotting contributors agree to abide by the code of conduct found in our [Code of Conduct](CODE_OF_CONDUCT.md) guidelines.

# Credits:
Development of ctm_plotting is a group effort. A list of developers that have contributed to the CTM Software framework 
are listed in the [Credits.md](CREDITS.md) file in this repository.

# License:
The CTM software is distributed under the BSD 3-Clause open-source license. 
Please see the [LICENSE.txt](LICENSE.txt) file for more information.
